export interface ICard {
  id: string;
  title?: string;
  poster_path?: string;
  release_date?: string;
  name?: string;
  first_air_date?: string;
}
