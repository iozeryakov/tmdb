import { FC } from "react";
import { MoviesLayout } from "../../layouts/MoviesLayout/MoviesLayout";

/**
 * Страница с фильмами
 */
export const Movies: FC = () => {
  return <MoviesLayout type="movie" name="Фильмы:" />;
};
