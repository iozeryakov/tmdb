import { FC, useState, useEffect, ChangeEvent, useRef } from "react";
import { MainLayout } from "../MainLayout/MainLayout";
import { APY_KEY, BASE_URL } from "../../urls/urls";
import { ICard } from "../../types/ICard";
import { Card2 } from "../../components/Card2/Card2";
import useLoading from "../../hooks/useLoading";
import axios from "axios";
import "./MoviesLayout.css";

interface IProp {
  type: string;
  name: string;
}

/**
 * Макет для второстепенных страниц
 */
export const MoviesLayout: FC<IProp> = ({ type, name }: IProp) => {
  //const [loading, setLoading] = useState(true);
  const [movies, setMovies] = useState<ICard[]>([]);
  const [page, setPage] = useState(1);
  const [method, setMethod] = useState(`/discover/${type}`);
  const [value, setValue] = useState("");
  const ref = useRef(null);
  const { data, isLoading, error } = useLoading<ICard[]>(
    BASE_URL +
      method +
      `?query=${value}&${APY_KEY}&page=${page}&sort_by=popularity.desc&language=ru`
  );
  useEffect(() => {
    if (data) {
      setMovies((prevState) => Array.from(new Set([...prevState, ...data])));
    }
  }, [data]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setPage((prevState) => prevState + 1);
        }
      },
      {
        root: null,
        rootMargin: "0px",
        threshold: 0.1,
      }
    );
    if (ref.current) {
      observer.observe(ref.current);
    }
  }, [ref]);

  useEffect(() => {
    if (value && value.trim()) {
      setMethod(`/search/${type}`);
    } else {
      setMethod(`/discover/${type}`);
    }
    setMovies([]);
    setPage(1);
  }, [value]);

  const onChangeValue = (event: ChangeEvent<HTMLInputElement>) => {
    setValue(event.target.value);
  };
  return (
    <MainLayout onChangeValue={onChangeValue}>
      <section className="main__section">
        <div className="section__wrapper">
          <div className="section__content">
            <div className="content__title">
              <h2 className="content__title_h2">
                {isLoading ? "Загрузка..." : movies.length === 0 ? "нет" : name}
              </h2>
            </div>
            <div className="content">
              <div>
                <div className="cards-wrapper">
                  <div className="cards">
                    {movies.map(
                      ({
                        id,
                        title,
                        poster_path,
                        release_date,
                        name,
                        first_air_date,
                      }) => {
                        return (
                          <Card2
                            key={id}
                            id={id}
                            title={title ? title : name}
                            poster_path={poster_path}
                            release_date={
                              release_date ? release_date : first_air_date
                            }
                          />
                        );
                      }
                    )}
                  </div>
                  <div className="button" ref={ref}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};
