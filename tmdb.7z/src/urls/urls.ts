export const APY_KEY = "api_key=df8ef6e41bdc22f50c14faf9a78a6da4"; //api
export const BASE_URL = "https://api.themoviedb.org/3"; //начало ссылки для api запроса
export const IMG_URL = "https://image.tmdb.org/t/p/w500"; //начало ссылки для img запроса
