import { useEffect, useState } from "react";
import axios from "axios";

interface State<T> {
  data?: T;
  isLoading: boolean;
  error?: Error;
}

export default function useLoading<T>(url: string): State<T> {
  const [data, setData] = useState();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error>();

  useEffect(() => {
    setIsLoading(true);
    axios
      .get(url)
      .then((movie) => {
        setData(movie.data.results);
      })
      .catch((error) => {
        setError(error);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [url]);

  return { data, isLoading, error };
}
